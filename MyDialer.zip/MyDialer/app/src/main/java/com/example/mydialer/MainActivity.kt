package com.example.mydialer

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.StrictMode
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.*
import com.google.gson.Gson
import timber.log.Timber
import timber.log.Timber.Forest.plant
import java.net.HttpURLConnection
import java.net.URL
import androidx.recyclerview.widget.DividerItemDecoration.VERTICAL

data class Contact (
    var name: String,
    var phone: String,
    var type: String
)
class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
    val name: TextView = itemView.findViewById(R.id.name)
    val phone: TextView = itemView.findViewById(R.id.phone)
    val type: TextView = itemView.findViewById(R.id.type)

    fun bindTo(data: Contact) {
        name.setText(data.name)
        phone.setText(data.phone)
        type.setText(data.type)

        itemView.setOnClickListener {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + data.phone))
            ContextCompat.startActivity(itemView.context, intent, null)
        }
    }
}

class Adapter : ListAdapter<Contact, ViewHolder>(ContactDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.rview_item, parent, false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = currentList[position]
        holder.bindTo(data)
    }
}

class ContactDiffCallback : DiffUtil.ItemCallback<Contact>() {
    override fun areItemsTheSame(oldItem: Contact, newItem: Contact): Boolean = oldItem == newItem
    override fun areContentsTheSame(oldItem: Contact, newItem: Contact): Boolean = oldItem == newItem
}

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)
        setContentView(R.layout.activity_main)
        plant(Timber.DebugTree())

        val recyclerView = findViewById<RecyclerView>(R.id.rView)
        val dividerItemDecoration = DividerItemDecoration(recyclerView.context, VERTICAL)
        recyclerView.addItemDecoration(dividerItemDecoration)
        val adapter = Adapter()

        val et = findViewById<EditText>(R.id.et_search)

        var contacts = arrayListOf<Contact>()

        val sharedPref = this@MainActivity.getSharedPreferences("app_preferences", Context.MODE_PRIVATE)
        if(sharedPref.contains("SEARCH_FILTER")) {
            et.setText(sharedPref.getString("SEARCH_FILTER", ""));
        }

        val url = URL("https://drive.google.com/u/0/uc?id=1-KO-9GA3NzSgIc1dkAsNm8Dqw0fuPxcR")
        Thread {
            val urlConnection: HttpURLConnection = url.openConnection() as HttpURLConnection
            var data = ""
            var contacts: ArrayList<Contact>
            try {
                data = urlConnection.inputStream.bufferedReader().readText()
            } finally {
                contacts =
                    Gson().fromJson(data, Array<Contact>::class.java).toList() as ArrayList<Contact>
            }
            urlConnection.disconnect()
            runOnUiThread() {
                recyclerView.layoutManager = LinearLayoutManager(this)
                recyclerView.adapter = adapter
                adapter.submitList(contacts)
            }

            et.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable) {
                    with (sharedPref.edit()) {
                        putString("SEARCH_FILTER", s.toString())
                        apply()
                    }
                }
                override fun beforeTextChanged(s: CharSequence, start: Int,
                                               count: Int, after: Int) {
                }
                override fun onTextChanged(s: CharSequence, start: Int,
                                           before: Int, count: Int) {
                    var contactSearch = arrayListOf<Contact>()
                    if (s != "") {
                        contacts.forEach { c ->
                            if (s.contains(c.name) || s.contains(c.phone) || s.contains(c.type)) {
                                contactSearch.add(c)
                            }
                        }
                        runOnUiThread() {
                            adapter.submitList(contactSearch)
                            //adapter.notifyDataSetChanged()
                        }
                    } else {
                        runOnUiThread() {
                            adapter.submitList(contacts)
                            //adapter.notifyDataSetChanged()
                        }
                    }
                }
            })
        }.start()
    }
}